package app.gui.controller;

import app.model.entity.*;
import app.model.repo.ProductRepo;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class AddProductController {
    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private Label extraLabel1, extraLabel2, extraLabel3, message;

    @FXML
    private TextField itemNumberTextField, nameTextField, quantityTextField, priceTextField, extraTextField1, extraTextField2, extraTextField3;

    private String type, itemNumber, name, extra1, extra2;

    private int quantity, extra3;

    private double price;

    public void onAddProductBtnClick() {
        if (type == null) {
            showMessage("Please select a product type", false);
            return;
        }

        if (itemNumberTextField.getText().isBlank() || nameTextField.getText().isBlank()
                || quantityTextField.getText().isBlank() || priceTextField.getText().isBlank()
                || extraTextField1.getText().isBlank() || extraTextField2.getText().isBlank()
                || extraTextField3.getText().isBlank()) {
            showMessage("Please fill in all fields", false);
            return;
        }

        itemNumber = itemNumberTextField.getText();
        name = nameTextField.getText();
        extra1 = extraTextField1.getText();
        extra2 = extraTextField2.getText();

        try {
            quantity = Integer.parseInt(quantityTextField.getText());
            price = Double.parseDouble(priceTextField.getText());
            extra3 = Integer.parseInt(extraTextField3.getText());
        } catch (NumberFormatException e) {
            showMessage("Quantity, price and " + extraLabel3.getText() + " must be numbers", false);
            return;
        }

        if (price < 0) {
            showMessage("Price cannot be negative", false);
            return;
        }

        Product newProduct;

        if (type == "Refrigerator") {
            newProduct = new Refrigerator(name, price, quantity, itemNumber, extra1, extra2, extra3);
        } else if (type == "TV") {
            newProduct = new TV(name, price, quantity, itemNumber, extra1, extra2, extra3);
        } else {
            newProduct = new HairDryer(name, price, quantity, itemNumber, extra1, extra2, extra3);
        }

        if (ProductRepo.productList.size() < ProductRepo.getMaxProduct()) {
            ProductRepo.addProduct(newProduct);
            showMessage("Product added successfully", true);
            clearFields();
        } else {
            showMessage("Max product reached", false);
        }
    }

    private void showMessage(String text, boolean success) {
        message.setText(text);
        message.setStyle(success ? "-fx-text-fill: green;" : "-fx-text-fill: red;");
        message.setVisible(true);
        PauseTransition pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(n -> message.setVisible(false));
        pause.play();
    }

    public void clearFields() {
        itemNumberTextField.setText("");
        nameTextField.setText("");
        quantityTextField.setText("");
        priceTextField.setText("");
        extraTextField1.setText("");
        extraTextField2.setText("");
        extraTextField3.setText("");
    }

    @FXML
    public void initialize() {
        typeComboBox.setItems(FXCollections.observableArrayList("Refrigerator", "TV", "Hair Dryer"));
        typeComboBox.setOnAction(n -> {
            type = typeComboBox.getValue();

            if (type == "Refrigerator") {
                extraLabel1.setText("Door Design");
                extraLabel2.setText("Color");
                extraLabel3.setText("Capacity (L)");
            } else if (type == "TV") {
                extraLabel1.setText("Screen Type");
                extraLabel2.setText("Resolution");
                extraLabel3.setText("Size (inches)");
            } else if (type == "Hair Dryer") {
                extraLabel1.setText("Nozzle Type");
                extraLabel2.setText("Color");
                extraLabel3.setText("Power (watts)");
            }
        });
    }
}
